from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path

from scraper.pipeline import run_pipeline


def build_parser() -> argparse.ArgumentParser:
    script_dir = Path(__file__).resolve().parent
    project_root = script_dir.parent
    review_date_token = date.today().strftime("%Y%m%d")
    snapshot_date = date.today().isoformat()

    parser = argparse.ArgumentParser(description="Scrape confirmed Hong Kong time-deposit offer pages.")
    parser.add_argument(
        "--source-registry",
        default=str(project_root / "input" / "Source Registry 20260417.csv"),
        help="Path to Source Registry CSV.",
    )
    parser.add_argument(
        "--output",
        default=str(project_root / "data" / f"TMD Competitor Price {review_date_token}.csv"),
        help="Output CSV path.",
    )
    parser.add_argument(
        "--snapshot-dir",
        default="",
        help="Optional directory containing local HTML snapshots to replay before falling back to live pages.",
    )
    parser.add_argument(
        "--archive-snapshots-db",
        action="store_true",
        help="Save live HTML/JSON/XML text responses to Postgres for replay/debugging.",
    )
    parser.add_argument(
        "--archive-snapshots-csv",
        default=str(project_root / "data" / f"website_capture_5days_{review_date_token}.csv"),
        help="CSV path used to save live HTML/JSON text responses locally.",
    )
    parser.add_argument(
        "--no-archive-snapshots-csv",
        action="store_true",
        help="Disable the default local website-capture CSV output.",
    )
    parser.add_argument(
        "--snapshot-date",
        default=snapshot_date,
        help="Snapshot date in YYYY-MM-DD format for archived source responses.",
    )
    parser.add_argument(
        "--snapshot-retention-days",
        type=int,
        default=5,
        help="Number of distinct source-response snapshot dates to retain in Postgres.",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    output_path = run_pipeline(
        source_registry_path=args.source_registry,
        output_path=args.output,
        snapshot_dir=args.snapshot_dir or None,
        archive_snapshots_db=args.archive_snapshots_db,
        archive_snapshots_csv=None if args.no_archive_snapshots_csv else args.archive_snapshots_csv,
        snapshot_date=args.snapshot_date,
        snapshot_retention_days=args.snapshot_retention_days,
    )
    print(f"Saved output to {output_path.resolve()}")


if __name__ == "__main__":
    main()
