from __future__ import annotations

import re
from typing import Iterable, Iterator, Optional


CODE_PATTERN = re.compile(r"\(([A-Z]{3})\)")
PERCENT_PATTERN = re.compile(r"(\d+(?:\s*\.\s*\d+)?)\s*%")
AMOUNT_PATTERN = re.compile(r"([A-Z]{3}|HKD|USD|RMB|CNY)\s*([\d,]+)")
TENOR_PATTERN = re.compile(r"^(\d+)(day|days|week|weeks|month|months|d|w|m)$")


def normalize_text(value: str) -> str:
    return " ".join(value.replace("\xa0", " ").replace("\\n", " ").split())


def normalize_tenor(value: str) -> str:
    cleaned = normalize_text(value).lower()
    compact = re.sub(r"[\s-]+", "", cleaned)
    match = TENOR_PATTERN.fullmatch(compact)
    if match:
        amount_text, unit_text = match.groups()
        amount = int(amount_text)
        if unit_text.startswith("day") or unit_text == "d":
            if amount == 7:
                return "1w"
            if amount == 14:
                return "2w"
            return f"{amount}d"
        if unit_text.startswith("week") or unit_text == "w":
            return f"{amount}w"
        return f"{amount}m"

    return value.strip()


def normalize_tenor_bucket(value: str) -> str:
    tenor = normalize_tenor(value)
    match = re.fullmatch(r"(\d+)([dwm])", tenor.lower())
    if not match:
        return tenor

    amount_text, unit = match.groups()
    amount = int(amount_text)
    if unit == "m":
        return tenor

    days = amount if unit == "d" else amount * 7
    months = days / 30
    if months < 1:
        return tenor

    bucket_months = max(1, int(months + 0.5))
    return f"{bucket_months}m"


def normalize_currency(value: str) -> str:
    cleaned = normalize_text(value)
    direct_map = {
        "港幣": "HKD",
        "港币": "HKD",
        "美元": "USD",
        "人民幣": "RMB",
        "人民币": "RMB",
    }
    if cleaned in direct_map:
        return direct_map[cleaned]
    code_match = CODE_PATTERN.search(cleaned)
    if code_match:
        code = code_match.group(1)
        return "RMB" if code == "CNY" else code
    direct = cleaned.upper()
    if direct == "CNY":
        return "RMB"
    return direct


def normalize_segment(value: str) -> str:
    return normalize_text(value).replace("  ", " ")


def normalize_rate(value: str) -> str:
    match = PERCENT_PATTERN.search(value)
    if not match:
        return ""
    return f"{float(match.group(1).replace(' ', '')):.2f}"


def normalize_new_fund_rate(value: str) -> str:
    cleaned = normalize_text(value)
    if "/" in cleaned:
        cleaned = cleaned.split("/", 1)[0]
    rate = normalize_rate(cleaned)
    if rate:
        return rate
    match = re.search(r"(\d+(?:\.\d+)?)", cleaned)
    if not match:
        return ""
    return f"{float(match.group(1)):.2f}"


def extract_amount(text: str, currency: str) -> str:
    currency_tokens = ["RMB", "CNY"] if currency == "RMB" else [currency]
    pattern = re.compile(rf"(?:{'|'.join(re.escape(token) for token in currency_tokens)})\s*([\d,]+)")
    match = pattern.search(text)
    return match.group(1).replace(",", "") if match else ""


def iter_table_rows(table) -> Iterator[list[str]]:
    for row in table.find_all("tr"):
        cells = row.find_all(["th", "td"])
        if not cells:
            continue
        yield [normalize_text(cell.get_text(" ", strip=True)) for cell in cells]


def find_next_tag(start, names: Iterable[str], stop_predicate=None):
    for element in start.find_all_next():
        if not getattr(element, "name", None):
            continue
        if stop_predicate and stop_predicate(element):
            return None
        if element.name in names:
            return element
    return None


def is_not_applicable(rate: str) -> bool:
    return normalize_text(rate).lower() in {"not applicable", "-", ""}


def parse_table_caption_amount(table) -> str:
    caption = table.find("caption")
    if caption is None:
        return ""
    return normalize_text(caption.get_text(" ", strip=True))


def first_percent(text: str) -> Optional[str]:
    match = PERCENT_PATTERN.search(text)
    if not match:
        return None
    return f"{float(match.group(1)):.2f}"
