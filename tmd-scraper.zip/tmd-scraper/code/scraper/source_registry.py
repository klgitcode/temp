from __future__ import annotations

import csv
from pathlib import Path

from scraper.models import SourceEntry


TARGET_BANKS = {
    "hsbc_hk",
    "hang_seng",
    "boc_hk",
    "dbs_hk",
    "scb_hk",
    "icbc_asia",
    "ccb_asia",
    "mox_bank",
    "cncbi_hk",
    "livi_bank",
    "welab_bank",
}


def load_source_registry(path: str | Path) -> list[SourceEntry]:
    entries: list[SourceEntry] = []
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            bank_code = (row.get("bank_code") or "").strip()
            if bank_code not in TARGET_BANKS:
                continue
            if not should_execute_scraper(row.get("execute_scraper")):
                continue
            entries.append(
                SourceEntry(
                    bank_code=bank_code,
                    bank_name_en=(row.get("bank_name_en") or "").strip(),
                    official_domain=(row.get("official_domain") or "").strip(),
                    tmd_type=(row.get("tmd_type") or "New Fund").strip(),
                    deposit_page_url=(row.get("deposit_page_url") or "").strip(),
                    source_type=(row.get("source_type") or "").strip(),
                    parser_strategy=(row.get("parser_strategy") or "").strip(),
                )
            )
    return entries


def should_execute_scraper(value: str | None) -> bool:
    """Only an explicit no-like flag disables a bank scraper."""
    return (value or "").strip().lower() not in {"n", "no", "false", "0"}
