from __future__ import annotations

import contextvars
import csv
import sys
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from urllib.parse import urlparse

from scraper.models import SourceEntry


PROJECT_ROOT = Path(__file__).resolve().parents[2]
BACKEND_ROOT = PROJECT_ROOT / "backend"


@dataclass(frozen=True)
class SnapshotArchiveConfig:
    enabled: bool = False
    snapshot_date: str = ""
    retention_days: int = 5


@dataclass(frozen=True)
class SourceResponseSnapshot:
    snapshot_date: str
    bank_code: str
    bank_name_en: str
    tmd_type: str
    parser_strategy: str
    source_url: str
    request_url: str
    content_type: str
    content: str
    content_length: int


_archive_config: contextvars.ContextVar[SnapshotArchiveConfig] = contextvars.ContextVar(
    "snapshot_archive_config",
    default=SnapshotArchiveConfig(),
)
_current_source: contextvars.ContextVar[SourceEntry | None] = contextvars.ContextVar("snapshot_archive_source", default=None)
_captured_snapshots: list[SourceResponseSnapshot] = []


def configure_snapshot_archive(*, enabled: bool, snapshot_date: str | None = None, retention_days: int = 5) -> None:
    effective_snapshot_date = snapshot_date or date.today().isoformat()
    _archive_config.set(
        SnapshotArchiveConfig(
            enabled=enabled,
            snapshot_date=effective_snapshot_date,
            retention_days=max(1, retention_days),
        )
    )
    _captured_snapshots.clear()


@contextmanager
def source_snapshot_context(source: SourceEntry):
    token = _current_source.set(source)
    try:
        yield
    finally:
        _current_source.reset(token)


def capture_text_response(*, bank_code: str, url: str, content_text: str) -> None:
    config = _archive_config.get()
    source = _current_source.get()
    if not config.enabled or source is None or not content_text:
        return

    effective_bank_code = bank_code or source.bank_code
    content_format = detect_content_format(url, content_text)
    if content_format not in {"html", "json"}:
        return

    encoded = content_text.encode("utf-8", errors="replace")
    _captured_snapshots.append(
        SourceResponseSnapshot(
            snapshot_date=config.snapshot_date,
            bank_code=effective_bank_code,
            bank_name_en=source.bank_name_en,
            tmd_type=source.tmd_type,
            parser_strategy=source.parser_strategy,
            source_url=source.deposit_page_url,
            request_url=url,
            content_type=content_type_for_format(content_format),
            content=content_text,
            content_length=len(encoded),
        )
    )


def has_captured_snapshots() -> bool:
    return bool(_captured_snapshots)


def write_snapshot_archive_csv(output_path: str | Path) -> int:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    snapshots = dedupe_snapshots(_captured_snapshots)
    fieldnames = [
        "snapshot_date",
        "bank_code",
        "bank_name_en",
        "tmd_type",
        "parser_strategy",
        "source_url",
        "request_url",
        "content_type",
        "content",
        "content_length",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for snapshot in snapshots:
            writer.writerow(snapshot.__dict__)
    return len(snapshots)


def flush_snapshot_archive_to_postgres() -> int:
    config = _archive_config.get()
    if not config.enabled or not _captured_snapshots:
        return 0

    from sqlalchemy import create_engine, text
    from sqlalchemy.pool import NullPool

    if str(BACKEND_ROOT) not in sys.path:
        sys.path.insert(0, str(BACKEND_ROOT))
    from app.config import get_settings

    settings = get_settings()
    engine = create_engine(
        settings.database_url,
        future=True,
        pool_pre_ping=True,
        poolclass=NullPool,
        connect_args={"prepare_threshold": None},
    )
    try:
        payloads = [snapshot.__dict__ for snapshot in dedupe_snapshots(_captured_snapshots)]
        with engine.begin() as connection:
            connection.execute(
                text(
                    """
                    insert into website_capture_5days (
                        snapshot_date,
                        bank_code,
                        bank_name_en,
                        tmd_type,
                        parser_strategy,
                        source_url,
                        request_url,
                        content_type,
                        content,
                        content_length
                    )
                    values (
                        :snapshot_date,
                        :bank_code,
                        :bank_name_en,
                        :tmd_type,
                        :parser_strategy,
                        :source_url,
                        :request_url,
                        :content_type,
                        :content,
                        :content_length
                    )
                    on conflict (
                        snapshot_date,
                        bank_code,
                        tmd_type,
                        request_url
                    )
                    do update set
                        bank_name_en = excluded.bank_name_en,
                        parser_strategy = excluded.parser_strategy,
                        source_url = excluded.source_url,
                        content_type = excluded.content_type,
                        content = excluded.content,
                        content_length = excluded.content_length,
                        captured_at = now()
                    """
                ),
                payloads,
            )
            delete_old_snapshots(connection, retention_days=config.retention_days)
        return len(payloads)
    finally:
        engine.dispose()


def dedupe_snapshots(snapshots: list[SourceResponseSnapshot]) -> list[SourceResponseSnapshot]:
    latest_by_key: dict[tuple[str, str, str, str], SourceResponseSnapshot] = {}
    for snapshot in snapshots:
        key = (snapshot.snapshot_date, snapshot.bank_code, snapshot.tmd_type, snapshot.request_url)
        latest_by_key[key] = snapshot
    return list(latest_by_key.values())


def delete_old_snapshots(connection, *, retention_days: int) -> int:
    from sqlalchemy import text

    result = connection.execute(
        text(
            """
            delete from website_capture_5days
            where snapshot_date not in (
                select snapshot_date
                from (
                    select distinct snapshot_date
                    from website_capture_5days
                    order by snapshot_date desc
                    limit :retention_days
                ) retained_dates
            )
            """
        ),
        {"retention_days": retention_days},
    )
    return result.rowcount or 0


def detect_content_format(url: str, content_text: str) -> str:
    path = urlparse(url).path.lower()
    stripped = content_text.lstrip()
    if path.endswith((".html", ".htm")) or stripped.lower().startswith(("<!doctype html", "<html")):
        return "html"
    if path.endswith(".json") or stripped.startswith(("{", "[")):
        return "json"
    if path.endswith(".xml") or stripped.lower().startswith("<?xml"):
        return "xml"
    if path.endswith(".js"):
        return "javascript"
    return "text"


def content_type_for_format(content_format: str) -> str:
    return {
        "html": "text/html",
        "json": "application/json",
        "xml": "application/xml",
        "javascript": "application/javascript",
    }.get(content_format, "text/plain")
