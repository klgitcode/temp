from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class SourceEntry:
    bank_code: str
    bank_name_en: str
    official_domain: str
    tmd_type: str
    deposit_page_url: str
    source_type: str
    parser_strategy: str


@dataclass(frozen=True)
class RateRecord:
    bank_code: str
    bank_name_en: str
    official_domain: str
    tmd_type: str
    customer_segment: str
    currency: str
    tenor: str
    min_amount: str
    interest_rate: str
    channel: str
    special_qualifiers: str
    review_date: str
    notes: str
    deposit_page_url: str
    source_type: str
    parser_strategy: str
    status: str

    def to_row(self) -> Dict[str, str]:
        return {
            "bank_code": self.bank_code,
            "bank_name_en": self.bank_name_en,
            "official_domain": self.official_domain,
            "tmd_type": self.tmd_type,
            "customer_segment": self.customer_segment,
            "currency": self.currency,
            "tenor": self.tenor,
            "min_amount": self.min_amount,
            "interest_rate": self.interest_rate,
            "channel": self.channel,
            "special_qualifiers": self.special_qualifiers,
            "review_date": self.review_date,
            "notes": self.notes,
            "deposit_page_url": self.deposit_page_url,
            "source_type": self.source_type,
            "parser_strategy": self.parser_strategy,
            "status": self.status,
        }
