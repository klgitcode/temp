from __future__ import annotations

import csv
import random
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import date
from pathlib import Path

from requests.exceptions import HTTPError, RequestException, Timeout

from scraper.fetchers import cleanup_snapshot_dir
from scraper.models import RateRecord, SourceEntry
from scraper.parsers.ccb_asia import CcbAsiaParser
from scraper.parsers.bochk import BochkParser
from scraper.parsers.cncbi_hk import CncbiParser
from scraper.parsers.dbs import DbsParser
from scraper.parsers.hang_seng import HangSengParser
from scraper.parsers.hsbc import HsbcParser
from scraper.parsers.icbc_asia import IcbcAsiaParser
from scraper.parsers.livi_bank import LiviBankParser
from scraper.parsers.mox_bank import MoxBankParser
from scraper.parsers.scb_hk import ScbParser
from scraper.parsers.welab_bank import WeLabBankParser
from scraper.snapshot_archive import (
    configure_snapshot_archive,
    flush_snapshot_archive_to_postgres,
    has_captured_snapshots,
    source_snapshot_context,
    write_snapshot_archive_csv,
)
from scraper.source_registry import load_source_registry


OUTPUT_COLUMNS = [
    "bank_code",
    "bank_name_en",
    "official_domain",
    "tmd_type",
    "customer_segment",
    "currency",
    "tenor",
    "min_amount",
    "interest_rate",
    "channel",
    "special_qualifiers",
    "review_date",
    "notes",
    "deposit_page_url",
    "source_type",
    "parser_strategy",
    "status",
]

PARSER_REGISTRY = {
    "hsbc_hk": HsbcParser(),
    "hang_seng": HangSengParser(),
    "boc_hk": BochkParser(),
    "dbs_hk": DbsParser(),
    "scb_hk": ScbParser(),
    "icbc_asia": IcbcAsiaParser(),
    "ccb_asia": CcbAsiaParser(),
    "mox_bank": MoxBankParser(),
    "cncbi_hk": CncbiParser(),
    "livi_bank": LiviBankParser(),
    "welab_bank": WeLabBankParser(),
}

NON_FATAL_SOURCES = {
    ("cncbi_hk", "FX TMD"),
}

MAX_SOURCE_ATTEMPTS = 3
RETRY_DELAY_RANGES_SECONDS = (
    (60, 120),
    (180, 300),
)


@dataclass(frozen=True)
class SourceFailure:
    entry: SourceEntry
    error: str
    attempt: int


def run_pipeline(
    source_registry_path: str,
    output_path: str,
    snapshot_dir: str | None = None,
    *,
    archive_snapshots_db: bool = False,
    archive_snapshots_csv: str | None = None,
    snapshot_date: str | None = None,
    snapshot_retention_days: int = 5,
) -> Path:
    entries = load_source_registry(source_registry_path)
    configure_snapshot_archive(
        enabled=(archive_snapshots_db or bool(archive_snapshots_csv)) and snapshot_dir is None,
        snapshot_date=snapshot_date,
        retention_days=snapshot_retention_days,
    )
    records: list[RateRecord] = []
    failures: list[SourceFailure] = []
    try:
        pending_entries = list(entries)
        for attempt in range(1, MAX_SOURCE_ATTEMPTS + 1):
            retry_entries: list[SourceEntry] = []
            if attempt > 1:
                print(
                    f"Retrying {len(pending_entries)} source registry entr"
                    f"{'y' if len(pending_entries) == 1 else 'ies'} "
                    f"(attempt {attempt}/{MAX_SOURCE_ATTEMPTS})."
                )

            # Retry by rounds instead of immediately so blocked domains get a cooling-off window
            # while unrelated banks can continue scraping.
            for entry in pending_entries:
                result = parse_source_entry(entry, snapshot_dir=snapshot_dir)
                if result.records:
                    if attempt > 1:
                        print(f"Recovered {entry.bank_code} {entry.tmd_type} on attempt {attempt}.")
                    records.extend(result.records)
                    continue

                if result.skip_without_failure:
                    continue

                if result.retryable and attempt < MAX_SOURCE_ATTEMPTS:
                    retry_entries.append(entry)
                    print(
                        f"WARNING: deferred {entry.bank_code} {entry.tmd_type} after attempt "
                        f"{attempt}/{MAX_SOURCE_ATTEMPTS}: {result.error}",
                        file=sys.stderr,
                    )
                else:
                    failures.append(SourceFailure(entry=entry, error=result.error, attempt=attempt))
                    print(
                        f"ERROR: skipped {entry.bank_code} {entry.tmd_type} after attempt "
                        f"{attempt}/{MAX_SOURCE_ATTEMPTS}: {result.error}",
                        file=sys.stderr,
                    )

            if not retry_entries:
                break

            sleep_before_retry_round(attempt, retry_count=len(retry_entries))
            pending_entries = retry_entries

        if failures:
            failure_summary = "; ".join(
                f"{failure.entry.bank_code} {failure.entry.tmd_type} "
                f"(attempts={failure.attempt}): {failure.error}"
                for failure in failures
            )
            raise RuntimeError(
                "Scraper failed because one or more enabled source registry entries did not produce data. "
                f"Failures: {failure_summary}"
            )

        if not records:
            raise RuntimeError("No rate records were scraped.")
        return write_output(records, output_path)
    finally:
        if archive_snapshots_csv and snapshot_dir is None and has_captured_snapshots():
            saved_count = write_snapshot_archive_csv(archive_snapshots_csv)
            print(f"Saved {saved_count} source response snapshot(s) to {archive_snapshots_csv}.")
        if archive_snapshots_db and snapshot_dir is None and has_captured_snapshots():
            saved_count = flush_snapshot_archive_to_postgres()
            print(f"Saved {saved_count} source response snapshot(s) to Postgres.")
        cleanup_snapshot_dir(snapshot_dir)


def is_non_fatal_source(bank_code: str, tmd_type: str) -> bool:
    return (bank_code, tmd_type) in NON_FATAL_SOURCES


@dataclass(frozen=True)
class SourceParseResult:
    records: list[RateRecord]
    error: str = ""
    retryable: bool = False
    skip_without_failure: bool = False


def parse_source_entry(entry: SourceEntry, *, snapshot_dir: str | None) -> SourceParseResult:
    try:
        parser = PARSER_REGISTRY[entry.bank_code]
        with source_snapshot_context(entry):
            parsed_records = parser.parse(entry, snapshot_dir=snapshot_dir)
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        if is_non_fatal_source(entry.bank_code, entry.tmd_type):
            print(
                f"WARNING: skipped {entry.bank_code} {entry.tmd_type} because this source is known to reject "
                f"GitHub-hosted runners intermittently: {error}",
                file=sys.stderr,
            )
            return SourceParseResult(records=[], error=error, skip_without_failure=True)

        return SourceParseResult(records=[], error=error, retryable=is_retryable_source_error(exc))

    if parsed_records:
        return SourceParseResult(records=parsed_records)

    error = "parser returned 0 records"
    if is_non_fatal_source(entry.bank_code, entry.tmd_type):
        print(
            f"WARNING: skipped {entry.bank_code} {entry.tmd_type} because this source is known to reject "
            "GitHub-hosted runners intermittently: parser returned 0 records.",
            file=sys.stderr,
        )
        return SourceParseResult(records=[], error=error, skip_without_failure=True)

    # Zero parsed rows usually means a page layout/data contract changed, so retrying rarely helps.
    return SourceParseResult(records=[], error=error, retryable=False)


def is_retryable_source_error(exc: Exception) -> bool:
    if isinstance(exc, HTTPError):
        status_code = exc.response.status_code if exc.response is not None else None
        return status_code in {403, 408, 409, 425, 429} or bool(status_code and 500 <= status_code <= 599)
    if isinstance(exc, Timeout):
        return True
    if isinstance(exc, RequestException):
        return True
    if isinstance(exc, subprocess.CalledProcessError):
        # curl returns 22 for HTTP >= 400 and 28 for timeout. Both often recover on a later runner attempt.
        return exc.returncode in {22, 28}
    return False


def sleep_before_retry_round(completed_attempt: int, *, retry_count: int) -> None:
    delay_range = RETRY_DELAY_RANGES_SECONDS[min(completed_attempt - 1, len(RETRY_DELAY_RANGES_SECONDS) - 1)]
    delay_seconds = random.randint(*delay_range)
    print(
        f"Waiting {delay_seconds}s before retrying {retry_count} source registry entr"
        f"{'y' if retry_count == 1 else 'ies'}."
    )
    time.sleep(delay_seconds)


def write_output(records: list[RateRecord], output_path: str) -> Path:
    rows = [record.to_row() for record in records]
    rows.sort(
        key=lambda row: (
            row["bank_code"],
            row["currency"],
            row["customer_segment"],
            row["tenor"],
            row["channel"],
            row["special_qualifiers"],
        )
    )
    path = _normalize_output_path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    return path


def _normalize_output_path(output_path: str) -> Path:
    path = Path(output_path)
    review_date_token = date.today().strftime("%Y%m%d")
    stem = re.sub(r"(?<!\d)\d{8}$", review_date_token, path.stem)
    if stem == path.stem and not re.search(r"(?<!\d)\d{8}$", path.stem):
        return path
    return path.with_name(f"{stem}{path.suffix}")
