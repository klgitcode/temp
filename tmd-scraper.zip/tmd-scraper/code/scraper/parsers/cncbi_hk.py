from __future__ import annotations

import requests
import shutil
import subprocess

from bs4 import BeautifulSoup

from scraper.fetchers import HEADERS, load_html
from scraper.models import RateRecord, SourceEntry
from scraper.parsers.base import BaseParser
from scraper.utils import iter_table_rows, normalize_currency, normalize_rate, normalize_tenor


class CncbiParser(BaseParser):
    """Parse CNCBI's inMotion FX Time Deposit offer page."""

    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        if source.tmd_type != "FX TMD":
            return []
        soup = self._load_soup(source, snapshot_dir)
        records: list[RateRecord] = []
        for table in soup.find_all("table"):
            rows = list(iter_table_rows(table))
            if len(rows) < 2 or rows[0][:3] != [
                "Designated Deposit Currency",
                "1 Week Deposit Rate (p.a.)",
                "1 Months Deposit Rate (p.a.)",
            ]:
                continue
            for row in rows[1:]:
                if len(row) < 3:
                    continue
                currency = normalize_currency(row[0])
                if currency not in self.supported_currencies:
                    continue
                for tenor, rate_text in (("1w", row[1]), ("1m", row[2])):
                    rate = normalize_rate(rate_text)
                    if not rate:
                        continue
                    records.append(
                        self.build_record(
                            source=source,
                            customer_segment="All eligible customers",
                            currency=currency,
                            tenor=tenor,
                            rate=rate,
                            min_amount="10000",
                            channel="inMotion",
                            special_qualifiers="single FX transaction and same-currency time deposit required",
                            notes="CNCBI page states minimum deposit amount is at least HKD10,000 or equivalent.",
                        )
                    )
            break
        return self.dedupe(records)

    def _load_soup(self, source: SourceEntry, snapshot_dir: str | None) -> BeautifulSoup:
        try:
            html = load_html(source.bank_code, source.deposit_page_url, snapshot_dir=snapshot_dir)
            if "Access Denied" not in html:
                return BeautifulSoup(html, "lxml")
        except Exception:
            pass

        headers = dict(HEADERS)
        headers["User-Agent"] = (
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
            "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 "
            "Mobile/15E148 Safari/604.1"
        )
        with requests.Session() as session:
            try:
                response = session.get(source.deposit_page_url, headers=headers, timeout=(15, 45), allow_redirects=True)
                response.raise_for_status()
                response.encoding = response.encoding or "utf-8"
                return BeautifulSoup(response.text, "lxml")
            except Exception:
                return BeautifulSoup(self._request_mobile_via_curl(source.deposit_page_url), "lxml")

    def _request_mobile_via_curl(self, url: str) -> str:
        curl_path = shutil.which("curl")
        if not curl_path:
            raise RuntimeError("curl is not installed or not available on PATH.")
        command = [
            curl_path,
            "--http1.1",
            "--compressed",
            "--location",
            "--silent",
            "--show-error",
            "--fail",
            "--user-agent",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
            "--header",
            "Accept-Language: en-HK,en;q=0.9",
            url,
        ]
        result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", timeout=60, check=True)
        return result.stdout
