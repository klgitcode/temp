from __future__ import annotations

from scraper.models import RateRecord, SourceEntry
from scraper.parsers.base import BaseParser
from scraper.utils import extract_amount, iter_table_rows, normalize_currency, normalize_rate, normalize_tenor


class IcbcAsiaParser(BaseParser):
    """Parse ICBC (Asia)'s branch new-funds promotion table."""

    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        soup = self.parse_html(source, snapshot_dir=snapshot_dir)
        records: list[RateRecord] = []

        for table in soup.find_all("table"):
            rows = list(iter_table_rows(table))
            if not rows or rows[0][:2] != ["Customer Segment", "New Funds Amount"]:
                continue
            records.extend(self._parse_offer_table(source, rows))

        return self.dedupe(records)

    def _parse_offer_table(self, source: SourceEntry, rows: list[list[str]]) -> list[RateRecord]:
        tenor_headers = [normalize_tenor(value) for value in rows[0][2:]]
        rate_column_count = len(tenor_headers)
        current_segment = ""
        records: list[RateRecord] = []

        for row in rows[1:]:
            if len(row) == rate_column_count + 2:
                current_segment = row[0]
                amount_text = row[1]
                rates = row[2:]
            elif len(row) == rate_column_count + 1:
                amount_text = row[0]
                rates = row[1:]
            else:
                continue

            currency = self._detect_currency(amount_text)
            if currency not in self.supported_currencies:
                continue
            min_amount = extract_amount(amount_text, currency)

            for tenor, rate_text in zip(tenor_headers, rates):
                rate = normalize_rate(rate_text)
                if not rate:
                    continue
                records.append(
                    self.build_record(
                        source=source,
                        customer_segment=current_segment or "Retail banking personal customers",
                        currency=currency,
                        tenor=tenor,
                        rate=rate,
                        min_amount=min_amount,
                        channel="branch",
                        special_qualifiers="eligible new funds",
                        notes="ICBC (Asia) page notes that activating Money Safe on the same branch placement may qualify for an extra 0.05% p.a.",
                    )
                )
        return records

    def _detect_currency(self, text: str) -> str:
        for candidate in ("HKD", "USD", "CNY", "RMB"):
            if candidate in text:
                return normalize_currency(candidate)
        return ""
