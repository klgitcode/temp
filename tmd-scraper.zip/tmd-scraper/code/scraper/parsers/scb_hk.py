from __future__ import annotations

import html
import json
import re

from scraper.models import RateRecord, SourceEntry
from scraper.parsers.base import BaseParser

from scraper.utils import extract_amount, iter_table_rows, normalize_currency, normalize_rate, normalize_tenor, normalize_text


class ScbParser(BaseParser):
    """Parse the public Standard Chartered online time-deposit rate tables."""

    NEW_FUND_HEADING_PATTERN = re.compile(
        r"\b(?P<currency>HKD|USD|RMB|CNY|AUD)\s+TIME\s+DEPOSIT\s+PREFERENTIAL\s+INTEREST\s+RATES\b",
        flags=re.IGNORECASE,
    )
    NEW_FUND_AMOUNT_PATTERN = re.compile(
        r"\b(?:REGULAR\s+)?NEW\s+FUNDS\s+OF\s+(?P<currency>HKD|USD|RMB|CNY|AUD)\s*[\d,]+\s+OR\s+ABOVE\b",
        flags=re.IGNORECASE,
    )
    FX_CUSTOMER_SEGMENTS = {
        "priority": "Priority Private or Priority Banking clients / Platinum Forex Members",
        "others": "Others",
    }

    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        soup = self.parse_html(source, snapshot_dir=snapshot_dir)
        if source.tmd_type == "FX TMD":
            return self.dedupe(self._parse_fx_tmd(source, soup))

        records: list[RateRecord] = []

        for table in soup.find_all("table"):
            rows = list(iter_table_rows(table))
            if len(rows) < 3:
                continue
            table_context = self._new_fund_table_context(table, rows)
            if table_context is None:
                continue
            currency, heading = table_context
            records.extend(self._parse_currency_table(source, currency, heading, rows))

        return self.dedupe(records)

    def _new_fund_table_context(self, table, rows: list[list[str]]) -> tuple[str, str] | None:
        amount_heading = rows[0][0] if rows and rows[0] else ""
        amount_match = self.NEW_FUND_AMOUNT_PATTERN.search(normalize_text(amount_heading).upper())
        if not amount_match:
            return None

        amount_currency = normalize_currency(amount_match.group("currency"))
        section_heading = self._nearest_previous_heading_text(table)
        section_match = self.NEW_FUND_HEADING_PATTERN.search(section_heading.upper())
        if section_match:
            section_currency = normalize_currency(section_match.group("currency"))
            if section_currency != amount_currency:
                return None
            return section_currency, amount_heading

        # Backward-compatible fallback for older captures where the table heading itself
        # was the most stable anchor.
        if amount_currency in self.supported_currencies:
            return amount_currency, amount_heading
        return None

    def _nearest_previous_heading_text(self, table) -> str:
        heading = table.find_previous(["h2", "h3", "h4", "h5"])
        return normalize_text(heading.get_text(" ", strip=True)) if heading else ""

    def _parse_currency_table(self, source: SourceEntry, currency: str, heading: str, rows: list[list[str]]) -> list[RateRecord]:
        min_amount = extract_amount(heading, currency)
        if currency not in self.supported_currencies:
            return []

        records: list[RateRecord] = []
        current_tenor = ""
        for row in rows[2:]:
            if len(row) >= 3 and normalize_currency(row[0]) == currency:
                current_tenor = row[1]
                rate_source = row[2]
            elif len(row) >= 2:
                current_tenor = row[0]
                rate_source = row[1]
            else:
                continue
            tenor = normalize_tenor(current_tenor)
            rate = normalize_rate(rate_source)
            if not rate:
                continue
            records.append(
                self.build_record(
                    source=source,
                    customer_segment="All eligible customers",
                    currency=currency,
                    tenor=tenor,
                    rate=rate,
                    min_amount=min_amount,
                    channel="online",
                    special_qualifiers="eligible new funds",
                    notes='Public online TD page defines "New Funds" separately in the FAQ section.',
                )
            )
        return records

    def _parse_fx_tmd(self, source: SourceEntry, soup) -> list[RateRecord]:
        """Parse Standard Chartered's high-yield FX time-deposit APR table."""
        config_records = self._parse_fx_tmd_config(source, soup)
        if config_records:
            return config_records

        records: list[RateRecord] = []
        for table in soup.find_all("table"):
            rows = list(iter_table_rows(table))
            if len(rows) < 3 or "Priority" not in " ".join(rows[0]):
                continue

            records.extend(self._parse_fx_tmd_table_rows(source, rows))
            break
        return records

    def _parse_fx_tmd_config(self, source: SourceEntry, soup) -> list[RateRecord]:
        config_node = soup.select_one(".fxtd-calc-config")
        if config_node is None:
            return []

        try:
            config = json.loads(html.unescape(config_node.get_text("", strip=True)))
        except json.JSONDecodeError:
            return []

        # SCB now renders the visible FX TMD matrix from this config. The
        # "other-channels" set is the public table split by Priority/Others;
        # keep the old static-table parser below as a fallback for archived pages.
        interest_rows = config.get("interests", {}).get("other-channels") or []
        records: list[RateRecord] = []
        for row in interest_rows:
            currency = normalize_currency(row.get("currencyTitle") or row.get("currency", ""))
            if currency not in self.supported_currencies:
                continue

            tenor = self._fx_tenor(row.get("tenure", ""))
            rate = normalize_rate(f"{row.get('interest', '')}%")
            if not tenor or not rate:
                continue

            for customer_type in row.get("customerType", []):
                segment = self.FX_CUSTOMER_SEGMENTS.get(normalize_text(str(customer_type)).lower())
                if not segment:
                    continue
                records.append(
                    self.build_record(
                        source=source,
                        customer_segment=segment,
                        currency=currency,
                        tenor=tenor,
                        rate=rate,
                        min_amount=self._fx_min_amount(currency),
                        channel="SC Mobile App,online banking,branch/My RM",
                        special_qualifiers="currency exchange required",
                        notes="SCB FX TMD rates are parsed from the page's fxtd-calc-config used to render the public rate table.",
                    )
                )
        return records

    def _parse_fx_tmd_table_rows(self, source: SourceEntry, rows: list[list[str]]) -> list[RateRecord]:
        segment_columns = [
            ("Priority Private or Priority Banking clients / Platinum Forex Members", "7d", 1),
            ("Priority Private or Priority Banking clients / Platinum Forex Members", "14d", 2),
            ("Others", "7d", 3),
            ("Others", "14d", 4),
        ]
        records: list[RateRecord] = []
        for row in rows[2:]:
            currency = normalize_currency(row[0])
            if currency not in self.supported_currencies:
                continue
            for segment, tenor, idx in segment_columns:
                if idx >= len(row):
                    continue
                rate = normalize_rate(row[idx])
                if not rate:
                    continue
                records.append(
                    self.build_record(
                        source=source,
                        customer_segment=segment,
                        currency=currency,
                        tenor=tenor,
                        rate=rate,
                        min_amount=self._fx_min_amount(currency),
                        channel="SC Mobile App,online banking,branch/My RM",
                        special_qualifiers="currency exchange required",
                        notes="SCB page states online minimum is HKD/RMB10,000 or 2,000 in original currency; branch/My RM minimum is HKD100,000 or equivalent.",
                    )
                )
        return records

    def _fx_tenor(self, tenure: str) -> str:
        cleaned = normalize_text(str(tenure))
        return f"{int(cleaned)}d" if cleaned.isdigit() else ""

    def _fx_min_amount(self, currency: str) -> str:
        return "10000" if currency in {"HKD", "RMB"} else "2000"
