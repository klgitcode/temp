from __future__ import annotations

import re

from scraper.models import RateRecord, SourceEntry
from scraper.parsers.base import BaseParser
from scraper.utils import extract_amount, iter_table_rows, normalize_currency, normalize_rate, normalize_tenor


class LiviBankParser(BaseParser):
    """Parse liviSave's public time-deposit rate tables."""

    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        if source.tmd_type != "New Fund":
            return []
        soup = self.parse_html(source, snapshot_dir=snapshot_dir)
        records: list[RateRecord] = []

        for table in soup.find_all("table"):
            rows = list(iter_table_rows(table))
            if len(rows) < 2:
                continue
            first_cell = rows[0][0]
            if first_cell == "Deposit Amount (HKD)":
                records.extend(self._parse_hkd_table(source, rows))
            elif len(rows[0]) >= 2 and rows[0][0] == "Tenor":
                currency = self._detect_currency(rows[0][1])
                if currency in {"USD", "RMB"}:
                    records.extend(self._parse_single_amount_table(source, currency, rows))
        return self.dedupe(records)

    def _parse_hkd_table(self, source: SourceEntry, rows: list[list[str]]) -> list[RateRecord]:
        amount_headers = rows[0][1:]
        records: list[RateRecord] = []
        for row in rows[1:]:
            if len(row) < 2:
                continue
            for amount_text, rate_text in zip(amount_headers, row[1:]):
                rate = normalize_rate(rate_text)
                if not rate:
                    continue
                records.append(
                    self.build_record(
                        source=source,
                        customer_segment="All eligible customers",
                        currency="HKD",
                        tenor=normalize_tenor(row[0]),
                        rate=rate,
                        min_amount=self._min_amount_from_hkd_header(amount_text),
                        channel="livi app",
                        special_qualifiers="public shared-rate page; workbook marked as New Fund source",
                        notes="liviSave page states actual rates are subject to rates quoted in the livi app.",
                    )
                )
        return records

    def _detect_currency(self, text: str) -> str:
        upper = text.upper()
        if upper.startswith("USD"):
            return "USD"
        if upper.startswith(("CNY", "RMB")):
            return "RMB"
        return normalize_currency(text)

    def _min_amount_from_hkd_header(self, text: str) -> str:
        match = re.search(r"\d[\d,]*", text)
        return match.group(0).replace(",", "") if match else ""

    def _parse_single_amount_table(self, source: SourceEntry, currency: str, rows: list[list[str]]) -> list[RateRecord]:
        min_amount = extract_amount(rows[0][1], currency)
        records: list[RateRecord] = []
        for row in rows[1:]:
            if len(row) < 2:
                continue
            rate = normalize_rate(row[1])
            if not rate:
                continue
            records.append(
                self.build_record(
                    source=source,
                    customer_segment="All eligible customers",
                    currency=currency,
                    tenor=normalize_tenor(row[0]),
                    rate=rate,
                    min_amount=min_amount,
                    channel="livi app",
                    special_qualifiers="public shared-rate page; workbook marked as New Fund source",
                    notes="liviSave page states actual rates are subject to rates quoted in the livi app.",
                )
            )
        return records
