from __future__ import annotations

import xml.etree.ElementTree as ET

from scraper.fetchers import load_html
from scraper.models import RateRecord, SourceEntry
from scraper.parsers.base import BaseParser
from scraper.utils import extract_amount, normalize_currency, normalize_rate, normalize_tenor


class CcbAsiaParser(BaseParser):
    """Parse the embedded XML feed behind CCB (Asia)'s deposit-rates page."""

    XML_URL = "https://www.asia.ccb.com/hongkong/personal/accounts/data/deps_rates.xml"

    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        xml_text = load_html(source.bank_code, self.XML_URL, snapshot_dir=snapshot_dir)
        root = ET.fromstring(xml_text)
        records: list[RateRecord] = []

        for rate_node in root.findall("./EN/Rate"):
            currency = normalize_currency(rate_node.findtext("Currency", default=""))
            if currency not in self.supported_currencies:
                continue
            amount_text = rate_node.findtext("Amount", default="")
            records.append(
                self.build_record(
                    source=source,
                    customer_segment="All eligible customers",
                    currency=currency,
                    tenor=normalize_tenor(rate_node.findtext("Term", default="")),
                    rate=normalize_rate(rate_node.findtext("AnnualRate", default="")),
                    min_amount=extract_amount(amount_text, currency),
                    channel="online banking,mobile banking,branch,smart teller machine",
                    special_qualifiers="eligible new fund balance",
                    notes="Rates are sourced from the public XML feed embedded in the CCB (Asia) deposit-rates page.",
                )
            )
        return self.dedupe(records)
