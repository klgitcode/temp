from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date
from typing import Iterable

from bs4 import BeautifulSoup

from scraper.fetchers import load_html
from scraper.models import RateRecord, SourceEntry


class BaseParser(ABC):
    supported_currencies = {"HKD", "USD", "RMB", "AUD"}
    tmd_type = "New Fund"
    status = "parsed"

    def parse_html(self, source: SourceEntry, snapshot_dir: str | None = None) -> BeautifulSoup:
        html = load_html(source.bank_code, source.deposit_page_url, snapshot_dir=snapshot_dir)
        return BeautifulSoup(html, "lxml")

    def build_record(
        self,
        source: SourceEntry,
        customer_segment: str,
        currency: str,
        tenor: str,
        rate: str,
        min_amount: str,
        channel: str,
        special_qualifiers: str = "",
        notes: str = "",
        tmd_type: str | None = None,
    ) -> RateRecord:
        return RateRecord(
            bank_code=source.bank_code,
            bank_name_en=source.bank_name_en,
            official_domain=source.official_domain,
            tmd_type=tmd_type or source.tmd_type or self.tmd_type,
            customer_segment=customer_segment,
            currency=currency,
            tenor=tenor,
            min_amount=min_amount,
            interest_rate=rate,
            channel=channel,
            special_qualifiers=special_qualifiers,
            review_date=date.today().isoformat(),
            notes=notes,
            deposit_page_url=source.deposit_page_url,
            source_type=source.source_type,
            parser_strategy=source.parser_strategy,
            status=self.status,
        )

    def dedupe(self, records: Iterable[RateRecord]) -> list[RateRecord]:
        seen = set()
        deduped: list[RateRecord] = []
        for record in records:
            if record.currency not in self.supported_currencies:
                continue
            key = (
                record.bank_code,
                record.customer_segment,
                record.currency,
                record.tenor,
                record.min_amount,
                record.channel,
                record.special_qualifiers,
                record.interest_rate,
            )
            if key in seen:
                continue
            seen.add(key)
            deduped.append(record)
        return deduped

    @abstractmethod
    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        raise NotImplementedError
