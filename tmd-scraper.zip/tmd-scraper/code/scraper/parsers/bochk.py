from __future__ import annotations

import re
import warnings

from scraper.models import RateRecord, SourceEntry
from scraper.parser_config import get_default_min_amount
from scraper.parsers.base import BaseParser
from scraper.utils import iter_table_rows, normalize_currency, normalize_rate, normalize_tenor, normalize_text


TENOR_CODE_PATTERN = re.compile(r"\d+[dwm]")
MIN_AMOUNT_PATTERN = re.compile(r"\b(HKD|USD|RMB|CNY|AUD)\s*\$?\s*([\d,]+(?:\.\d+)?)", re.IGNORECASE)
NEW_FUND_MIN_AMOUNT_MARKERS = (
    "minimum eligible new fund balance",
    "minimum amount",
    "minimum deposit amount",
)


class BochkParser(BaseParser):
    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        soup = self.parse_html(source, snapshot_dir=snapshot_dir)
        if source.tmd_type == "FX TMD":
            return self.dedupe(self._parse_fx_tmd(source, soup))

        tables = soup.find_all("table")
        if not tables:
            return []
        return self.dedupe(self._parse_standard_new_fund_table(source, tables[0], soup))

    def _parse_standard_new_fund_table(self, source: SourceEntry, table, soup) -> list[RateRecord]:
        rows = self._expand_table_rows(table)
        if not rows:
            return []

        header = rows[0]
        tenor_columns = [
            (index, normalize_tenor(value))
            for index, value in enumerate(header)
            if self._is_tenor_header(value)
        ]
        if not tenor_columns:
            return []

        currency_col = self._find_column(header, ("currency",))
        segment_col = self._find_column(header, ("integrated account services",))
        channel_col = self._find_column(header, ("application channel",))
        if currency_col is None or segment_col is None:
            return []

        currencies = self._standard_table_currencies(rows[1:], currency_col)
        min_amounts = self._standard_min_amounts(source, soup, currencies)
        records: list[RateRecord] = []
        for row in rows[1:]:
            if currency_col >= len(row) or segment_col >= len(row):
                continue

            currency = normalize_currency(row[currency_col])
            if currency not in self.supported_currencies:
                continue

            segment = row[segment_col]
            channel = self._normalize_channel(row[channel_col] if channel_col is not None and channel_col < len(row) else "")
            for column_index, tenor in tenor_columns:
                if column_index >= len(row):
                    continue
                rate_text = row[column_index]
                rate = normalize_rate(rate_text)
                if not rate:
                    continue
                min_amount = min_amounts.get(currency, "")
                if not min_amount:
                    raise ValueError(f"BOCHK New Fund parsed {currency} rates but could not determine min_amount.")
                records.append(
                    self.build_record(
                        source=source,
                        customer_segment=segment,
                        currency=currency,
                        tenor=tenor,
                        rate=rate,
                        min_amount=min_amount,
                        channel=channel.lower(),
                        special_qualifiers="eligible new fund balance",
                        notes=self._standard_min_amount_note(min_amounts),
                    )
                )
        return records

    def _expand_table_rows(self, table) -> list[list[str]]:
        rows: list[list[str]] = []
        rowspans: dict[int, tuple[str, int]] = {}

        for html_row in table.find_all("tr"):
            cells = html_row.find_all(["th", "td"])
            if not cells:
                continue

            row: list[str] = []
            column_index = 0

            def append_pending_spans() -> None:
                nonlocal column_index
                while column_index in rowspans:
                    text, remaining = rowspans[column_index]
                    row.append(text)
                    if remaining <= 1:
                        del rowspans[column_index]
                    else:
                        rowspans[column_index] = (text, remaining - 1)
                    column_index += 1

            for cell in cells:
                append_pending_spans()
                text = normalize_text(cell.get_text(" ", strip=True))
                rowspan = self._parse_span(cell.get("rowspan"))
                colspan = self._parse_span(cell.get("colspan"))

                for _ in range(colspan):
                    row.append(text)
                    if rowspan > 1:
                        rowspans[column_index] = (text, rowspan - 1)
                    column_index += 1

            append_pending_spans()
            rows.append(row)

        return rows

    @staticmethod
    def _parse_span(value: str | None) -> int:
        try:
            return max(1, int(value or "1"))
        except ValueError:
            return 1

    @staticmethod
    def _find_column(header: list[str], aliases: tuple[str, ...]) -> int | None:
        for index, value in enumerate(header):
            normalized = normalize_text(value).lower()
            if any(alias in normalized for alias in aliases):
                return index
        return None

    @staticmethod
    def _is_tenor_header(value: str) -> bool:
        return bool(TENOR_CODE_PATTERN.fullmatch(normalize_tenor(value).lower()))

    @staticmethod
    def _normalize_channel(value: str) -> str:
        return normalize_text(value).lower().replace(", ", ",") or "internet banking,mobile banking"

    def _standard_table_currencies(self, rows: list[list[str]], currency_col: int) -> set[str]:
        currencies: set[str] = set()
        for row in rows:
            if currency_col >= len(row):
                continue
            currency = normalize_currency(row[currency_col])
            if currency in self.supported_currencies:
                currencies.add(currency)
        return currencies

    def _standard_min_amounts(self, source: SourceEntry, soup, currencies: set[str]) -> dict[str, str]:
        parsed_amounts = self._parse_standard_min_amounts(soup)
        fallback_currencies = currencies - set(parsed_amounts)
        fallback_amounts = {
            currency: get_default_min_amount(source.bank_code, source.tmd_type, currency)
            for currency in fallback_currencies
        }
        fallback_amounts = {currency: amount for currency, amount in fallback_amounts.items() if amount}
        if fallback_amounts:
            warnings.warn(
                "BOCHK New Fund min_amount was not fully parsed from page text; "
                f"using configured fallback for {', '.join(sorted(fallback_amounts))}.",
                RuntimeWarning,
                stacklevel=2,
            )
        return {**fallback_amounts, **parsed_amounts}

    def _parse_standard_min_amounts(self, soup) -> dict[str, str]:
        page_text = normalize_text(soup.get_text(" ", strip=True))
        lowered_text = page_text.lower()
        search_windows: list[str] = []
        for marker in NEW_FUND_MIN_AMOUNT_MARKERS:
            start = lowered_text.find(marker)
            if start >= 0:
                search_windows.append(page_text[start : start + 400])

        for window in search_windows:
            amounts = self._parse_currency_amounts(window)
            if amounts:
                return amounts
        return {}

    @staticmethod
    def _parse_currency_amounts(text: str) -> dict[str, str]:
        amounts: dict[str, str] = {}
        for currency_text, amount_text in MIN_AMOUNT_PATTERN.findall(text):
            currency = normalize_currency(currency_text)
            normalized_amount = amount_text.replace(",", "")
            if "." in normalized_amount:
                normalized_amount = normalized_amount.rstrip("0").rstrip(".")
            amounts[currency] = normalized_amount
        return amounts

    @staticmethod
    def _standard_min_amount_note(min_amounts: dict[str, str]) -> str:
        formatted = " / ".join(
            f"{currency}{int(amount):,}"
            for currency, amount in sorted(min_amounts.items())
            if amount.isdigit()
        )
        if not formatted:
            return "BOCHK New Fund minimum eligible new fund balance parsed from page text or configured fallback."
        return f"Minimum eligible new fund balance: {formatted}."

    def _parse_fx_tmd(self, source: SourceEntry, soup) -> list[RateRecord]:
        """Parse BOCHK's Preferential RMB & FX Time Deposit Offer table."""
        records: list[RateRecord] = []
        for table in soup.find_all("table"):
            rows = list(iter_table_rows(table))
            if len(rows) < 4 or not rows[0]:
                continue
            if rows[0][0] != "Deposit Tenor" or "Application Channel" not in rows[0][-1]:
                continue
            currency_headers = [normalize_currency(value) for value in rows[1]]
            if "AUD" not in currency_headers or "USD" not in currency_headers:
                continue

            for row in rows[2:]:
                tenor = normalize_tenor(row[0])
                for currency, rate_text in zip(currency_headers, row[1:]):
                    if currency not in self.supported_currencies:
                        continue
                    rate = normalize_rate(rate_text)
                    if not rate:
                        continue
                    records.append(
                        self.build_record(
                            source=source,
                            customer_segment="All eligible customers",
                            currency=currency,
                            tenor=tenor,
                            rate=rate,
                            min_amount=self._fx_min_amount(currency),
                            channel="internet banking,mobile banking",
                            special_qualifiers="currency conversion required",
                            notes="BOCHK Preferential RMB & FX Time Deposit requires placement by conversion of funds.",
                        )
                    )
            break
        return records

    def _fx_min_amount(self, currency: str) -> str:
        return "10000" if currency == "RMB" else "1000"
