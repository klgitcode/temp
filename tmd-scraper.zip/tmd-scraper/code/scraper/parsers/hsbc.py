from __future__ import annotations

from bs4 import BeautifulSoup

from scraper.models import RateRecord, SourceEntry
from scraper.parsers.base import BaseParser
from scraper.utils import (
    extract_amount,
    iter_table_rows,
    normalize_rate,
    normalize_currency,
    normalize_segment,
    normalize_tenor,
    parse_table_caption_amount,
)


class HsbcParser(BaseParser):
    DEFAULT_MIN_HKD = "10000"
    DEFAULT_MIN_USD = "2000"
    DEFAULT_MIN_RMB = "10000"
    DEFAULT_MIN_AUD = "2000"

    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        soup = self.parse_html(source, snapshot_dir=snapshot_dir)
        if source.tmd_type == "FX TMD":
            return self.dedupe(self._parse_fx_tmd(soup, source))

        records: list[RateRecord] = []

        records.extend(self._parse_segment_tabs(soup, source, "Preferential HKD New Fund Time Deposit Rates – online offer", "HKD", "online"))
        records.extend(self._parse_segment_tabs(soup, source, "Preferential USD New Fund Time Deposit Rates – online offer", "USD", "online"))
        records.extend(self._parse_segment_tabs(soup, source, "Preferential RMB New Fund Time Deposit Rates – online offer", "RMB", "online"))
        records.extend(
            self._parse_segment_tabs(
                soup,
                source,
                "Preferential Foreign Currency New Fund Time Deposit Rates – online offer",
                "AUD",
                "online",
                special_qualifiers="foreign currency new fund",
            )
        )

        records.extend(self._parse_segment_tabs(soup, source, "Preferential HKD New Fund Time Deposit Rates – branch/phone-banking offer", "HKD", "branch/phone-banking"))
        records.extend(self._parse_segment_tabs(soup, source, "Preferential USD New Fund Time Deposit Rates – branch/phone-banking offer", "USD", "branch/phone-banking"))
        records.extend(self._parse_segment_tabs(soup, source, "Preferential RMB New Fund Time Deposit Rates – branch/phone-banking offer", "RMB", "branch/phone-banking"))
        records.extend(
            self._parse_segment_tabs(
                soup,
                source,
                "Preferential Foreign Currency New Fund Time Deposit Rates – branch/phone-banking offer",
                "AUD",
                "branch/phone-banking",
                special_qualifiers="foreign currency new fund",
            )
        )

        return self.dedupe(records)

    def _find_heading(self, soup: BeautifulSoup, heading_text: str):
        return soup.find(["h2", "h3", "h5"], string=lambda s: s and heading_text in " ".join(s.split()))

    def _parse_segment_tabs(
        self,
        soup: BeautifulSoup,
        source: SourceEntry,
        heading_text: str,
        currency: str,
        channel: str,
        special_qualifiers: str = "",
    ) -> list[RateRecord]:
        heading = self._find_heading(soup, heading_text)
        if heading is None:
            return []
        tabs = heading.find_next("div", class_="tabsHorizontal")
        if tabs is None:
            return []

        records: list[RateRecord] = []
        for segment_label, table in self._iter_tab_tables(tabs):
            caption_text = parse_table_caption_amount(table)
            min_amount = ""
            if currency == "HKD":
                min_amount = extract_amount(caption_text, "HKD") or self.DEFAULT_MIN_HKD
            elif currency == "USD":
                min_amount = extract_amount(caption_text, "USD") or self.DEFAULT_MIN_USD
            elif currency == "RMB":
                min_amount = extract_amount(caption_text, "RMB") or self.DEFAULT_MIN_RMB
            elif currency == "AUD":
                min_amount = extract_amount(caption_text, "AUD") or self.DEFAULT_MIN_AUD

            for row in list(iter_table_rows(table))[1:]:
                if len(row) < 2:
                    continue
                tenor = normalize_tenor(row[0])
                rate = normalize_rate(row[1])
                if not rate:
                    continue
                notes = caption_text if currency == "RMB" else ""
                records.append(
                    self.build_record(
                        source=source,
                        customer_segment=segment_label,
                        currency=currency,
                        tenor=tenor,
                        rate=rate,
                        min_amount=min_amount,
                        channel=channel,
                        special_qualifiers=special_qualifiers,
                        notes=notes,
                    )
                )
        return records

    def _iter_tab_tables(self, tabs_container):
        labels = [normalize_segment(link.get_text(" ", strip=True)) for link in tabs_container.select("ul.tab-widget-list a.tab-widget-link")]
        contents = tabs_container.select("div.tab-widget-tabs > div.tab-widget-tab-content")
        for label, content in zip(labels, contents):
            table = content.select_one("table.desktop")
            if table is None:
                continue
            yield label, table

    def _parse_fx_tmd(self, soup: BeautifulSoup, source: SourceEntry) -> list[RateRecord]:
        """Parse HSBC's FX Time Deposit tables. New fund is explicitly not required."""
        records: list[RateRecord] = []
        segment_order = [
            "HSBC Premier Elite / HSBC Global Private Banking",
            "HSBC Premier",
            "HSBC One / Others",
        ]
        desktop_table_index = 0
        for table in soup.find_all("table"):
            rows = list(iter_table_rows(table))
            if len(rows) < 2 or len(rows[0]) < 3:
                continue
            if not rows[0][0].startswith("Currency Exchanged to"):
                continue

            segment = segment_order[desktop_table_index % len(segment_order)]
            desktop_table_index += 1
            tenors = [normalize_tenor(value.replace("Interest rates (p.a.) for", "").replace("Interest rates for", "").replace("tenor (p.a.)", "").strip()) for value in rows[0][1:]]
            for row in rows[1:]:
                currency = normalize_currency(row[0])
                if currency not in self.supported_currencies:
                    continue
                min_amount = "10000" if currency == "RMB" else "2000"
                for tenor, rate_text in zip(tenors, row[1:]):
                    rate = normalize_rate(rate_text)
                    if not rate:
                        continue
                    records.append(
                        self.build_record(
                            source=source,
                            customer_segment=segment,
                            currency=currency,
                            tenor=tenor,
                            rate=rate,
                            min_amount=min_amount,
                            channel="mobile banking",
                            special_qualifiers="currency exchange required,new fund not required",
                            notes="HSBC FX Time Deposit page states the offer requires currency exchange and new fund is not required.",
                        )
                    )
        return records
