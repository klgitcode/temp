from __future__ import annotations

import json
from urllib.parse import urljoin

from scraper.fetchers import load_html
from scraper.models import RateRecord, SourceEntry
from scraper.parsers.base import BaseParser
from scraper.utils import normalize_currency, normalize_rate, normalize_tenor


class WeLabBankParser(BaseParser):
    """Parse WeLab Bank's GoSave 2.0 JSON feed used by the public page."""

    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        if source.tmd_type != "New Fund":
            return []

        # The HTML table initially shows "Loading...", then the frontend fetches
        # /gosave.json. This feed is the public GoSave 2.0 rate source.
        self.parse_html(source, snapshot_dir=snapshot_dir)
        json_url = urljoin(source.deposit_page_url, "/gosave.json")
        data = json.loads(load_html(source.bank_code, json_url, snapshot_dir=snapshot_dir))
        english_feed = next((item for item in data if item.get("language") == "en"), data[0] if data else {})

        records: list[RateRecord] = []
        for currency_node in english_feed.get("currency", []):
            currency = normalize_currency(currency_node.get("name", ""))
            if currency not in self.supported_currencies:
                continue
            note = currency_node.get("note", "")
            for rate_node in currency_node.get("rates", []):
                rate = normalize_rate(rate_node.get("rate", ""))
                if not rate:
                    continue
                records.append(
                    self.build_record(
                        source=source,
                        customer_segment="All eligible customers",
                        currency=currency,
                        tenor=normalize_tenor(rate_node.get("tenor", "")),
                        rate=rate,
                        min_amount="",
                        channel="WeLab Bank app",
                        special_qualifiers="GoSave 2.0 public JSON feed; min/max amount shown in app",
                        notes=note,
                    )
                )
        return self.dedupe(records)
