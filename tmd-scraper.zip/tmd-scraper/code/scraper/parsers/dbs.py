from __future__ import annotations

import re

from bs4 import BeautifulSoup

from scraper.models import RateRecord, SourceEntry
from scraper.parsers.base import BaseParser
from scraper.utils import first_percent, iter_table_rows, normalize_currency, normalize_rate, normalize_tenor


class DbsParser(BaseParser):
    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        soup = self.parse_html(source, snapshot_dir=snapshot_dir)
        if source.tmd_type == "FX TMD":
            return self.dedupe(self._parse_fx_tmd(source, soup))

        tables = soup.find_all("table")
        records: list[RateRecord] = []

        for table in tables:
            rows = list(iter_table_rows(table))
            if len(rows) < 4:
                continue
            if not rows[0] or not rows[0][0].startswith("Deposit amount:"):
                continue
            if rows[1][1:3] != ["General DBS Customer", "DBS Treasures and Private Client #"]:
                continue
            first_code = rows[3][2] if len(rows[3]) > 2 else ""
            if not first_code.startswith("Q"):
                continue
            records.extend(self._parse_new_fund_table(source, rows))

        records.extend(self._build_bonus_note_records(source, soup))
        return self.dedupe(records)

    def _parse_new_fund_table(self, source: SourceEntry, rows: list[list[str]]) -> list[RateRecord]:
        deposit_line = rows[0][0]
        currency = normalize_currency(deposit_line.split(":", 1)[1].split()[0])
        min_amount = deposit_line.split(":", 1)[1].split()[1].replace(",", "")
        records: list[RateRecord] = []
        segments = ("General DBS Customer", "DBS Treasures and Private Client")

        for row in rows[3:]:
            tenor = normalize_tenor(row[0])
            general_rate = normalize_rate(row[1])
            treasures_rate = normalize_rate(row[3])
            rate_values = {
                segments[0]: general_rate,
                segments[1]: treasures_rate,
            }
            promo_codes = {
                segments[0]: row[2],
                segments[1]: row[4],
            }
            for segment in segments:
                rate = rate_values[segment]
                if not rate:
                    continue
                records.append(
                    self.build_record(
                        source=source,
                        customer_segment=segment,
                        currency=currency,
                        tenor=tenor,
                        rate=rate,
                        min_amount=min_amount,
                        channel="online",
                        notes=f"Promotion code: {promo_codes[segment]}. Deposit amount on page: {deposit_line.split(':', 1)[1].strip()}.",
                    )
                )
        return records

    def _build_bonus_note_records(self, source: SourceEntry, soup: BeautifulSoup) -> list[RateRecord]:
        text = soup.get_text("\n", strip=True)
        offer_match = re.search(
            r"register for\s+(?P<tenor_text>[\d\sor/and,-]+)-month\s+HKD and/or USD online time deposit"
            r".*?eligible new funds of HKD\s*(?P<hkd_amount>[\d,]+)"
            r".*?USD\s*(?P<usd_amount>[\d,]+)"
            r".*?HKD\s*(?P<hkd_rate>\d+(?:\.\d+)?)%\s*(?:p\.a\.)?"
            r".*?USD\s*(?P<usd_rate>\d+(?:\.\d+)?)%",
            text,
            flags=re.I | re.S,
        )
        if not offer_match:
            return []

        tenors = [normalize_tenor(f"{month} months") for month in re.findall(r"\d+", offer_match.group("tenor_text"))]
        if not tenors:
            return []

        hkd_bonus = first_percent(f"HKD {offer_match.group('hkd_rate')}%")
        usd_bonus = first_percent(f"USD {offer_match.group('usd_rate')}%")
        hkd_amount = offer_match.group("hkd_amount").replace(",", "")
        usd_amount = offer_match.group("usd_amount").replace(",", "")
        notes = (
            "Page separately advertises a quota-limited bonus interest reward for HKD/USD online time deposits "
            f"with eligible new funds of HKD{offer_match.group('hkd_amount')} and/or USD{offer_match.group('usd_amount')}. "
            "This is stored separately from the base online offer table."
        )
        records: list[RateRecord] = []
        for tenor in tenors:
            records.append(
                self.build_record(
                    source=source,
                    customer_segment="All eligible customers",
                    currency="HKD",
                    tenor=tenor,
                    rate=hkd_bonus,
                    min_amount=hkd_amount,
                    channel="online",
                    special_qualifiers="bonus interest reward,quota-limited,registration required",
                    notes=notes,
                )
            )
            records.append(
                self.build_record(
                    source=source,
                    customer_segment="All eligible customers",
                    currency="USD",
                    tenor=tenor,
                    rate=usd_bonus,
                    min_amount=usd_amount,
                    channel="online",
                    special_qualifiers="bonus interest reward,quota-limited,registration required",
                    notes=notes,
                )
            )
        return records

    def _parse_fx_tmd(self, source: SourceEntry, soup: BeautifulSoup) -> list[RateRecord]:
        """Parse DBS's Foreign Exchange Time Deposit preferential-rate table."""
        records: list[RateRecord] = []
        for table in soup.find_all("table"):
            rows = list(iter_table_rows(table))
            if len(rows) < 2 or not rows[0] or rows[0][0] != "Tenor":
                continue
            if "Preferential Rate" not in " ".join(rows[0]):
                continue

            for row in rows[1:]:
                if len(row) < 4:
                    continue
                tenor = normalize_tenor(row[0])
                currency = normalize_currency(row[1])
                if currency not in self.supported_currencies:
                    continue
                for channel, rate_text in (
                    ("online", row[2]),
                    ("branch", row[3]),
                ):
                    rate = normalize_rate(rate_text)
                    if not rate:
                        continue
                    records.append(
                        self.build_record(
                            source=source,
                            customer_segment="All eligible customers",
                            currency=currency,
                            tenor=tenor,
                            rate=rate,
                            min_amount="",
                            channel=channel,
                            special_qualifiers="currency exchange required",
                            notes="DBS FXTD page defines eligible FX transaction and eligible new-funds conditions for some customers.",
                        )
                    )
            break
        return records
