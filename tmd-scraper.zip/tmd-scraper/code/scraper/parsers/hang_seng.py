from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from datetime import datetime
from urllib.parse import urljoin

from scraper.fetchers import load_html
from scraper.models import RateRecord, SourceEntry
from scraper.parsers.base import BaseParser
from scraper.utils import extract_amount, iter_table_rows, normalize_currency, normalize_rate, normalize_segment, normalize_tenor, normalize_text


class HangSengParser(BaseParser):
    XML_PATH_PATTERN = re.compile(r'var\s+path\s*=\s*"([^"]+)"')
    TENOR_NUMBER_GROUP_PATTERN = re.compile(
        r"^\s*(?P<numbers>\d+(?:\s*(?:/|,|and|or)\s*\d+)+)\s*(?P<unit>days?|weeks?|months?|[dwm])\s*$",
        flags=re.IGNORECASE,
    )

    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        if source.tmd_type == "FX TMD":
            soup = self.parse_html(source, snapshot_dir=snapshot_dir)
            return self.dedupe(self._parse_fx_tmd(source, soup))

        xml_root = self._load_xml_root(source, snapshot_dir)
        offer = self._get_active_offer(xml_root)
        if offer is None:
            return []

        reference_date = offer.findtext("reference_date/eng", default="")
        segment_names = {
            "signature": normalize_segment(offer.findtext("signature_name/eng", default="Signature")),
            "prestige": normalize_segment(offer.findtext("prestige_name/eng", default="Prestige")),
            "preferred": normalize_segment(offer.findtext("preferred_name/eng", default="Preferred")),
        }

        records: list[RateRecord] = []
        records.extend(self._parse_featured_offers(source, offer, segment_names, reference_date))
        records.extend(self._parse_currency_offers(source, offer, segment_names, reference_date))
        return self.dedupe(records)

    def _load_xml_root(self, source: SourceEntry, snapshot_dir: str | None) -> ET.Element:
        load_html(source.bank_code, source.deposit_page_url, snapshot_dir=snapshot_dir)
        script_url = urljoin(source.deposit_page_url, "../js/getXML.js")
        script_text = load_html("", script_url)
        match = self.XML_PATH_PATTERN.search(script_text)
        xml_url = urljoin(source.deposit_page_url, match.group(1)) if match else urljoin(source.deposit_page_url, "../xml/fund_2023.xml")
        xml_text = load_html("", xml_url).lstrip("\ufeffï»¿")
        return ET.fromstring(xml_text)

    def _get_active_offer(self, root: ET.Element) -> ET.Element | None:
        now = datetime.now()
        for parameter in root.find("HangSeng").findall("Parameter"):
            effective = datetime.strptime(parameter.attrib["effectiveDate"], "%Y-%m-%d %H:%M:%S")
            expiry = datetime.strptime(parameter.attrib["expiryDate"], "%Y-%m-%d %H:%M:%S")
            if effective <= now <= expiry:
                return root.find(parameter.text or "")
        return None

    def _parse_featured_offers(
        self,
        source: SourceEntry,
        offer: ET.Element,
        segment_names: dict[str, str],
        reference_date: str,
    ) -> list[RateRecord]:
        featured = offer.find("featured")
        if featured is None:
            return []

        subtitle = normalize_text(featured.findtext("subtitle/eng", default=""))
        notes = f"Reference date on Hang Seng XML: {reference_date}." if reference_date else ""
        records: list[RateRecord] = []
        for offer_node in featured.findall("offer"):
            currency = normalize_currency(offer_node.findtext("principal/eng", default=""))
            if currency not in self.supported_currencies:
                continue
            tenors = self._expand_tenors(offer_node.findtext("tenor/eng", default=""))
            min_amount = self._extract_min_amount(subtitle, currency)
            for segment_key, customer_segment in segment_names.items():
                rate = normalize_text(offer_node.findtext(f"rate/{segment_key}", default=""))
                if not rate:
                    continue
                for tenor in tenors:
                    records.append(
                        self.build_record(
                            source=source,
                            customer_segment=customer_segment,
                            currency=currency,
                            tenor=tenor,
                            rate=rate,
                            min_amount=min_amount,
                            channel="online",
                            special_qualifiers="eligible new fund balance,featured online exclusive offer",
                            notes=notes,
                        )
                    )
        return records

    def _parse_currency_offers(
        self,
        source: SourceEntry,
        offer: ET.Element,
        segment_names: dict[str, str],
        reference_date: str,
    ) -> list[RateRecord]:
        channel_map = {
            "channel_1": "online",
            "channel_2": "branch/phone-banking",
        }
        notes = f"Reference date on Hang Seng XML: {reference_date}." if reference_date else ""
        records: list[RateRecord] = []

        for currency_node in offer.findall("currency"):
            title = normalize_text(currency_node.findtext("title/eng", default=""))
            currency = normalize_currency(title.split(" ", 1)[0])
            if currency not in self.supported_currencies:
                continue
            min_amount = self._extract_min_amount(title, currency)
            for tenor_node in currency_node.findall("tenor"):
                tenors = self._expand_tenors(tenor_node.findtext("name/eng", default=""))
                for channel_key, channel in channel_map.items():
                    channel_node = tenor_node.find(channel_key)
                    if channel_node is None:
                        continue
                    for segment_key, customer_segment in segment_names.items():
                        rate = normalize_text(channel_node.findtext(segment_key, default=""))
                        if not rate:
                            continue
                        for tenor in tenors:
                            records.append(
                                self.build_record(
                                    source=source,
                                    customer_segment=customer_segment,
                                    currency=currency,
                                    tenor=tenor,
                                    rate=rate,
                                    min_amount=min_amount,
                                    channel=channel,
                                    special_qualifiers="eligible new fund balance",
                                    notes=notes,
                                )
                            )
        return records

    def _expand_tenors(self, value: str) -> list[str]:
        cleaned = normalize_text(value).lower().replace("-", " ")
        match = self.TENOR_NUMBER_GROUP_PATTERN.fullmatch(cleaned)
        if not match:
            return [normalize_tenor(value)]

        unit = match.group("unit")
        tenors: list[str] = []
        for number in re.findall(r"\d+", match.group("numbers")):
            tenor = normalize_tenor(f"{number} {unit}")
            if tenor not in tenors:
                tenors.append(tenor)
        return tenors

    def _extract_min_amount(self, text: str, currency: str) -> str:
        amount = extract_amount(text, currency)
        if amount:
            return amount
        defaults = {
            "HKD": "10000",
            "USD": "2000",
            "RMB": "10000",
            "AUD": "2000",
        }
        return defaults.get(currency, "")

    def _parse_fx_tmd(self, source: SourceEntry, soup) -> list[RateRecord]:
        """Parse Hang Seng's FX Time Deposit tables, preferring the current layout."""
        current_records = self._parse_current_fx_tmd(source, soup)
        if current_records:
            return current_records

        records: list[RateRecord] = []
        for table in soup.find_all("table"):
            rows = list(iter_table_rows(table))
            if len(rows) < 4:
                continue
            if not rows[0] or not rows[0][0] == "" or "Time Deposit Amount of" not in " ".join(rows[0]):
                continue
            if len(rows[1]) < 3 or "Via Hang Seng Mobile App" not in rows[1][1]:
                continue

            amount_text = rows[0][1].replace("HKDE", "HKD")
            min_amount = extract_amount(amount_text, "HKD")
            channels = rows[1][1:]
            tenor_cells = [normalize_tenor(value) for value in rows[2][1:]]
            columns: list[tuple[str, str, int]] = []
            if len(channels) == 2 and len(tenor_cells) == 4:
                columns = [
                    (channels[0], tenor_cells[0], 1),
                    (channels[0], tenor_cells[1], 2),
                    (channels[1], tenor_cells[2], 3),
                    (channels[1], tenor_cells[3], 4),
                ]

            for row in rows[3:]:
                currency = normalize_currency(row[0])
                if currency not in self.supported_currencies:
                    continue
                for channel, tenor, idx in columns:
                    if idx >= len(row):
                        continue
                    rate = normalize_rate(row[idx])
                    if not rate:
                        continue
                    records.append(
                        self.build_record(
                            source=source,
                            customer_segment="All eligible customers",
                            currency=currency,
                            tenor=tenor,
                            rate=rate,
                            min_amount=min_amount,
                            channel=channel,
                            special_qualifiers="currency exchange required",
                            notes=f"Hang Seng FX Time Deposit amount tier: {amount_text}.",
                        )
                    )
        return records

    def _parse_current_fx_tmd(self, source: SourceEntry, soup) -> list[RateRecord]:
        """Parse Hang Seng's June 2026 FX TMD layout.

        The current page no longer tiers deposit rates by transaction amount.
        Cash rebates still vary by transaction count, but they are not TMD rates.
        """
        min_amount = "10000"
        notes = (
            "Hang Seng FX Time Deposit minimum FX transaction: HKD10,000 or equivalent. "
            "Cash rewards by transaction count are not captured as TMD rates."
        )
        records: list[RateRecord] = []

        vip_panel = soup.find(id="flash-panel-1")
        if vip_panel is not None:
            for table in self._desktop_tables(vip_panel):
                rows = list(iter_table_rows(table))
                if not self._is_current_tenor_rate_table(rows):
                    continue
                records.extend(
                    self._records_from_tenor_rate_table(
                        source=source,
                        rows=rows,
                        customer_segment="Prestige Private / Prestige Banking",
                        channel="Via Hang Seng Mobile App / Hang Seng Personal e-Banking / Phone Banking Hotlines / branches",
                        min_amount=min_amount,
                        notes=notes,
                    )
                )

        preferred_panel = soup.find(id="flash-panel-2")
        if preferred_panel is not None:
            for table in self._desktop_tables(preferred_panel):
                rows = list(iter_table_rows(table))
                if not self._is_current_channel_rate_table(rows):
                    continue
                records.extend(
                    self._records_from_channel_rate_table(
                        source=source,
                        rows=rows,
                        customer_segment="Preferred Banking / Integrated Account",
                        min_amount=min_amount,
                        notes=notes,
                    )
                )

        return self.dedupe(records)

    def _desktop_tables(self, container) -> list:
        tables = container.find_all("table", class_="md-block")
        return tables or container.find_all("table")

    def _is_current_tenor_rate_table(self, rows: list[list[str]]) -> bool:
        return (
            len(rows) >= 2
            and len(rows[0]) >= 3
            and rows[0][0] == "Tenor"
            and normalize_tenor(rows[0][1]) == "1w"
            and normalize_tenor(rows[0][2]) == "1m"
        )

    def _is_current_channel_rate_table(self, rows: list[list[str]]) -> bool:
        return (
            self._is_current_tenor_rate_table(rows)
            and len(rows) >= 3
            and len(rows[1]) >= 5
            and rows[1][0] == "Trading Channels"
            and "Via Hang Seng Mobile App" in rows[1][1]
            and "Via Phone Banking" in rows[1][2]
        )

    def _records_from_tenor_rate_table(
        self,
        source: SourceEntry,
        rows: list[list[str]],
        customer_segment: str,
        channel: str,
        min_amount: str,
        notes: str,
    ) -> list[RateRecord]:
        records: list[RateRecord] = []
        tenor_columns = [(normalize_tenor(rows[0][1]), 1), (normalize_tenor(rows[0][2]), 2)]
        for row in rows[1:]:
            if len(row) < 3:
                continue
            currency = normalize_currency(row[0])
            if currency not in self.supported_currencies:
                continue
            for tenor, idx in tenor_columns:
                rate = normalize_rate(row[idx])
                if not rate:
                    continue
                records.append(
                    self.build_record(
                        source=source,
                        customer_segment=customer_segment,
                        currency=currency,
                        tenor=tenor,
                        rate=rate,
                        min_amount=min_amount,
                        channel=channel,
                        special_qualifiers="currency exchange required",
                        notes=notes,
                    )
                )
        return records

    def _records_from_channel_rate_table(
        self,
        source: SourceEntry,
        rows: list[list[str]],
        customer_segment: str,
        min_amount: str,
        notes: str,
    ) -> list[RateRecord]:
        records: list[RateRecord] = []
        columns = [
            (rows[1][1], normalize_tenor(rows[0][1]), 1),
            (rows[1][2], normalize_tenor(rows[0][1]), 2),
            (rows[1][3], normalize_tenor(rows[0][2]), 3),
            (rows[1][4], normalize_tenor(rows[0][2]), 4),
        ]
        for row in rows[2:]:
            if len(row) < 5:
                continue
            currency = normalize_currency(row[0])
            if currency not in self.supported_currencies:
                continue
            for channel, tenor, idx in columns:
                rate = normalize_rate(row[idx])
                if not rate:
                    continue
                records.append(
                    self.build_record(
                        source=source,
                        customer_segment=customer_segment,
                        currency=currency,
                        tenor=tenor,
                        rate=rate,
                        min_amount=min_amount,
                        channel=channel,
                        special_qualifiers="currency exchange required",
                        notes=notes,
                    )
                )
        return records
