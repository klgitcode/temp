from __future__ import annotations

from scraper.models import RateRecord, SourceEntry
from scraper.parsers.base import BaseParser
from scraper.utils import iter_table_rows, normalize_rate, normalize_tenor


class MoxBankParser(BaseParser):
    """Parse Mox's public new-funds time-deposit tables."""

    TABLE_CURRENCIES = ("USD", "HKD")

    def parse(self, source: SourceEntry, snapshot_dir: str | None = None) -> list[RateRecord]:
        soup = self.parse_html(source, snapshot_dir=snapshot_dir)
        if source.tmd_type == "FX TMD":
            return self.dedupe(self._parse_fx_tmd(source, soup))

        records: list[RateRecord] = []

        for currency, table in zip(self.TABLE_CURRENCIES, soup.find_all("table")[:2]):
            rows = list(iter_table_rows(table))
            if len(rows) < 2 or rows[0][:2] not in (
                ["Tenor", "Preferential interest rate (p.a.)"],
                ["Tenor (USD)", "Time Deposit Rate (p.a.)"],
            ):
                continue
            records.extend(self._parse_currency_table(source, currency, rows))

        return self.dedupe(records)

    def _parse_currency_table(self, source: SourceEntry, currency: str, rows: list[list[str]]) -> list[RateRecord]:
        records: list[RateRecord] = []
        min_amount = "1"

        for row in rows[1:]:
            if len(row) < 2:
                continue
            rate = normalize_rate(row[1])
            if not rate:
                continue
            records.append(
                self.build_record(
                    source=source,
                    customer_segment="All eligible customers",
                    currency=currency,
                    tenor=normalize_tenor(row[0]),
                    rate=rate,
                    min_amount=min_amount,
                    channel="mox app",
                    special_qualifiers="eligible new funds",
                    notes="Parser intentionally excludes the separate FX-conversion limited-time USD offer because the project currently excludes FX-related TMD offers from New Fund output.",
                )
            )
        return records

    def _parse_fx_tmd(self, source: SourceEntry, soup) -> list[RateRecord]:
        """Parse Mox's limited-time HKD-to-USD FX Time Deposit table."""
        tables = soup.find_all("table")
        if len(tables) < 3:
            return []
        rows = list(iter_table_rows(tables[2]))
        if len(rows) < 2 or rows[0][:2] != ["Tenor (USD)", "Time Deposit Rate (p.a.)"]:
            return []

        records: list[RateRecord] = []
        for row in rows[1:]:
            if len(row) < 2:
                continue
            rate = normalize_rate(row[1])
            if not rate:
                continue
            records.append(
                self.build_record(
                    source=source,
                    customer_segment="All eligible customers",
                    currency="USD",
                    tenor=normalize_tenor(row[0]),
                    rate=rate,
                    min_amount="1",
                    channel="mox app",
                    special_qualifiers="HKD to USD conversion required,limited-time offer",
                    notes="Mox page states customers convert HKD to USD and then set up a USD time deposit.",
                )
            )
        return records
