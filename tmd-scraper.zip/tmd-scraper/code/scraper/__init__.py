"""TMD competitor scraper package."""

