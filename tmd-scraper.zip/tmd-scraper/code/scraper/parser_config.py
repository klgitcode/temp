from __future__ import annotations


DEFAULT_MIN_AMOUNTS = {
    ("boc_hk", "New Fund"): {
        "HKD": "10000",
        "USD": "1000",
        "RMB": "10000",
        "AUD": "1000",
    },
    ("boc_hk", "FX TMD"): {
        "AUD": "1000",
        "RMB": "10000",
        "USD": "1000",
    },
}


def get_default_min_amount(bank_code: str, tmd_type: str, currency: str) -> str:
    return DEFAULT_MIN_AMOUNTS.get((bank_code, tmd_type), {}).get(currency, "")
