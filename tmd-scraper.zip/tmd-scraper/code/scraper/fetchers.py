from __future__ import annotations

import shutil
import ssl
import subprocess
from pathlib import Path
from typing import Optional

import certifi
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import RequestException, SSLError
from urllib3.util.retry import Retry


HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/125.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-HK,en;q=0.9,zh-HK;q=0.8,zh;q=0.7",
    "Connection": "close",
}


class Tls12HttpAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        context = ssl.create_default_context()
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.maximum_version = ssl.TLSVersion.TLSv1_2
        kwargs["ssl_context"] = context
        return super().init_poolmanager(*args, **kwargs)


def build_session(force_tls12: bool = False) -> requests.Session:
    retry = Retry(
        total=3,
        connect=3,
        read=3,
        backoff_factor=1.0,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset({"GET"}),
        raise_on_status=False,
    )
    adapter_cls = Tls12HttpAdapter if force_tls12 else HTTPAdapter
    adapter = adapter_cls(max_retries=retry)
    session = requests.Session()
    session.headers.update(HEADERS)
    session.verify = certifi.where()
    session.mount("https://", adapter)
    session.mount("http://", HTTPAdapter(max_retries=retry))
    return session


def find_snapshot_path(bank_code: str, snapshot_dir: Optional[str], suffix: str = ".html") -> Path | None:
    if not snapshot_dir:
        return None

    directory = Path(snapshot_dir)
    aliases = {
        "hsbc_hk": ["hsbc_hk", "hsbc"],
        "boc_hk": ["boc_hk", "bochk", "boc"],
        "dbs_hk": ["dbs_hk", "dbs"],
    }.get(bank_code, [bank_code])

    for alias in aliases:
        explicit_candidates = [directory / f"{alias}{suffix}"]
        explicit_candidates.extend(sorted(directory.glob(f"{alias}_*{suffix}"), reverse=True))
        for candidate in explicit_candidates:
            if candidate.exists():
                return candidate
    return None


def request_html(url: str, force_tls12: bool = False) -> str:
    session = build_session(force_tls12=force_tls12)
    try:
        response = session.get(url, timeout=(15, 45), allow_redirects=True)
        response.raise_for_status()
        response.encoding = response.encoding or "utf-8"
        return response.text
    finally:
        session.close()


def request_html_via_curl(url: str) -> str:
    curl_path = shutil.which("curl")
    if not curl_path:
        raise RuntimeError("curl is not installed or not available on PATH.")

    command = [
        curl_path,
        "--http1.1",
        "--compressed",
        "--location",
        "--silent",
        "--show-error",
        "--fail",
        "--user-agent",
        HEADERS["User-Agent"],
        "--header",
        f"Accept: {HEADERS['Accept']}",
        "--header",
        f"Accept-Language: {HEADERS['Accept-Language']}",
        url,
    ]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", timeout=60, check=True)
    return result.stdout


def request_bytes(url: str, force_tls12: bool = False) -> bytes:
    session = build_session(force_tls12=force_tls12)
    try:
        response = session.get(url, timeout=(15, 45), allow_redirects=True)
        response.raise_for_status()
        return response.content
    finally:
        session.close()


def request_bytes_via_curl(url: str) -> bytes:
    curl_path = shutil.which("curl")
    if not curl_path:
        raise RuntimeError("curl is not installed or not available on PATH.")

    command = [
        curl_path,
        "--http1.1",
        "--compressed",
        "--location",
        "--silent",
        "--show-error",
        "--fail",
        "--user-agent",
        HEADERS["User-Agent"],
        "--header",
        f"Accept: {HEADERS['Accept']}",
        "--header",
        f"Accept-Language: {HEADERS['Accept-Language']}",
        url,
    ]
    result = subprocess.run(command, capture_output=True, timeout=60, check=True)
    return result.stdout


def load_html(bank_code: str, url: str, snapshot_dir: Optional[str] = None) -> str:
    snapshot_path = find_snapshot_path(bank_code, snapshot_dir)
    if snapshot_path is not None:
        return snapshot_path.read_text(encoding="utf-8", errors="ignore")

    try:
        content = request_html(url)
    except SSLError:
        try:
            content = request_html(url, force_tls12=True)
        except RequestException:
            content = request_html_via_curl(url)

    from scraper.snapshot_archive import capture_text_response

    capture_text_response(bank_code=bank_code, url=url, content_text=content)
    return content


def load_bytes(bank_code: str, url: str, snapshot_dir: Optional[str] = None, suffix: str = ".pdf") -> bytes:
    snapshot_path = find_snapshot_path(bank_code, snapshot_dir, suffix=suffix)
    if snapshot_path is not None:
        return snapshot_path.read_bytes()

    try:
        return request_bytes(url)
    except SSLError:
        try:
            return request_bytes(url, force_tls12=True)
        except RequestException:
            return request_bytes_via_curl(url)


def cleanup_snapshot_dir(snapshot_dir: Optional[str]) -> list[Path]:
    if not snapshot_dir:
        return []

    directory = Path(snapshot_dir)
    if not directory.exists():
        return []

    deleted: list[Path] = []
    patterns = (
        "hsbc*.html",
        "bochk*.html",
        "boc*.html",
        "dbs*.html",
    )
    seen: set[Path] = set()
    for pattern in patterns:
        for path in directory.glob(pattern):
            if path in seen or not path.is_file():
                continue
            seen.add(path)
            path.unlink(missing_ok=True)
            deleted.append(path)
    return deleted
