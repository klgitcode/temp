# 银行定期存款利率爬虫交接

用途：读取银行公开页面，生成当日利率 CSV。

## 环境与运行

建议 Python 3.13（原自动任务使用此版本），系统需有 curl 并可访问银行网站。日期按机器本地时区生成，请将执行机器设为香港/上海时区。

在解压后的项目目录执行（macOS / Linux）：

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r code/requirements.txt
.venv/bin/python code/run_competitor_scraper.py --no-archive-snapshots-csv
```

Windows 使用 `py -3 -m venv .venv` 创建环境，后续 Python 命令替换为 `.venv\Scripts\python.exe`；确保 curl 在 PATH 中。

输出为 `data/TMD Competitor Price YYYYMMDD.csv`，目录自动创建。
需要保存原始网页用于排查时，可省略 `--no-archive-snapshots-csv`，会额外生成 `data/website_capture_5days_YYYYMMDD.csv`。本地文件不会自动保留仅五天，需自行清理。

## 每日执行

使用接收方机器自己的任务调度器，每天按香港/上海时间运行一次上述爬虫命令，并设置完整的 Python 和脚本路径，保存标准输出/错误日志；避免同时启动多个实例。本包不含现有项目的入库/AI 定时任务。

## 配置与排错

- `input/Source Registry 20260417.csv` 是程序当前默认使用的清单；文件名中的日期不代表必须改为今天。
- `execute_scraper=N` 表示暂停的来源，清单保留当前设置；这七家银行的解析器已从交付包排除，并同步删除导入和注册项。要恢复这些银行，必须先补回源码及注册配置，不能只改 N。
- 银行网页调整或网络限制可能导致抓取失败；程序最多尝试三轮，轮次之间可能等待数分钟。
- 多数启用来源失败会导致非零退出且不写出当日利率文件；cncbi_hk 的 FX TMD 目前属于允许跳过的来源，应检查日志。
- 不要启用 `--archive-snapshots-db`：此交付包不含入库组件或凭据。
- 不建议日常使用 `--snapshot-dir`；当前代码会清理该目录下部分匹配的 HTML 文件，若回放应仅使用可丢弃副本。
